import { reactRouter } from "@react-router/dev/vite";
import tailwindcss from "@tailwindcss/vite";
import { defineConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  base: "/uui-2025/studenti/ognjen_antonic_mi25204/",
  plugins: [tailwindcss(), reactRouter(), tsconfigPaths()],
});
