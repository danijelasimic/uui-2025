import CustomLatex from "~/components/CustomLatex";

const BinaryRelations = () => {
  return <div className="page">
      <h1>Binary relations</h1>
      <p>
        A relation is binary if it is a subset of the cartesian product
        of a set by itself.&nbsp;
        <CustomLatex latex={"\\small A^2 = A \\times A"} block={false} />. If a and b
        are both elements of A and they are related to each other (the relation
        contains the element (a, b)), we can write that as a ρ b. Let's take the
        set&nbsp;
        <CustomLatex latex={"\\small A = \\{a, b, c, d, e\\}"} block={false} />. If we
        want to define or examine a binary relation on this set, we can do it
        easily using a table, like so:
      </p>

      <table className="square-table" style={{"--rows": 6} as React.CSSProperties}>
          <thead>
            <tr>
              <th><div><CustomLatex latex="\small A" block={false} /></div></th>
              <th><div><CustomLatex latex="\small a" block={false} /></div></th>
              <th><div><CustomLatex latex="\small b" block={false} /></div></th>
              <th><div><CustomLatex latex="\small c" block={false} /></div></th>
              <th><div><CustomLatex latex="\small d" block={false} /></div></th>
              <th><div><CustomLatex latex="\small e" block={false} /></div></th>
            </tr>
          </thead>
         
          <tbody>
             <tr>
              <th><div><CustomLatex latex="\small a" block={false} /></div></th>
              <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
            </tr>
            <tr>
              <th><div><CustomLatex latex="\small b" block={false} /></div></th>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
            </tr>
            <tr>
              <th><div><CustomLatex latex="\small c" block={false} /></div></th>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
            </tr>
            <tr>
              <th><div><CustomLatex latex="\small d" block={false} /></div></th>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
            </tr>
            <tr>
              <th><div><CustomLatex latex="\small e" block={false} /></div></th>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
              <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
            </tr>
          </tbody>
      </table>
      <p>
        The table represents each combination of 2 elements from A. 1 means that
        that combination appears in the relation, and 0 means that it does not. So
        the relation described in this table would look like:
      </p>
      <CustomLatex
        latex={"\\rho = \\{(a, a), (b, b), (c, c), (d, d), (e, e)\\}"}
      />
      <p>
        Each element of <CustomLatex latex="A \times A" block={false} /> corresponds to either a 1 or a 0. In other words,
        there is a mapping of each element from A×A to the set <CustomLatex latex="\small \{0, 1\}" block={false} />. This is actually a function, and it's known as
        the characteristic function&nbsp;
        <CustomLatex
          latex={"\\small f_\{\\rho\} : A \\times A \\to \\{0, 1\\}"}
          block={false}
        />
        . We can pass any element of A×A to this function, and it will return 1
        if it's inside the relation, so&nbsp;
        <CustomLatex latex={"\\small f_\{\\rho\}((d, d)) = 1"} block={false} />. The
        table above also allows us to see the matrix property of a binary
        relation, and we can clearly see why the collection of pairs with the
        same elements is known as the diagonal.
      </p>
      <h2>Properties</h2>
      <p>
        We can describe any binary relation ρ of a set A using these properties:
      </p>
      <dl>
        <dt>Reflexivity</dt>
        <dd>Does the relation contain the entire diagonal?</dd>
        <dt>Antireflexivity</dt>
        <dd>Does the relation contain zero elements from the diagonal?</dd>
        <dt>Symmetry</dt>
        <dd>
          Does it contain the element on the opposite side of the diagonal for
          each element?
        </dd>
        <dt>Antisymmetry</dt>
        <dd>
          Does it contain zero elements that are on the opposite side of the
          diagonal for any of the elements?
        </dd>
        <dt>Transitivity</dt>
        <dd>If it contains (a, b) and (b, c), does it also contain (a, c)?</dd>
      </dl>
      <h3>Reflexivity</h3>
      <p>
        This is the simplest one. Does the relation contain every element in the
        format (x, x)? The collection of all elements in this format is known as
        the diagonal, and we can formally write this as:
      </p>
      <CustomLatex latex={"(\\forall a \\in A)(a, a) \\in \\rho"} />
      <h3>Antireflexivity</h3>
      <p>
        This one is also fairly simple, the relation is antireflexive if it
        doesn't contain any elements from the diagonal. Formally we write it
        down as:
      </p>
      <CustomLatex latex={"(\\forall a \\in A)(a, a) \\notin \\rho"} />
      <h3>Symmetry</h3>
      <p>
        This is where things start to get a bit confusing. It states that for
        each element, the element on the opposite side of the diagonal must also
        be included. In other words, if (a, b) is an element, (b, a) is also an
        element. Or formally:
      </p>
      <CustomLatex latex={"(a, b) \\in \\rho \\implies (b, a) \\in \\rho"} />
      <p>Here is an example of one such relation:</p>
      <table className="square-table" style={{"--rows": 6} as React.CSSProperties}>
      <thead>
         <tr>
          <th><div><CustomLatex latex="\small A" block={false} /></div></th>
          <th><div><CustomLatex latex="\small a" block={false} /></div></th>
          <th><div><CustomLatex latex="\small b" block={false} /></div></th>
          <th><div><CustomLatex latex="\small c" block={false} /></div></th>
          <th><div><CustomLatex latex="\small d" block={false} /></div></th>
          <th><div><CustomLatex latex="\small e" block={false} /></div></th>
        </tr>
      </thead>

      <tbody>
         <tr>
          <th><div><CustomLatex latex="\small a" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small b" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small c" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small d" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small e" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
        </tr>
 
      </tbody>
      </table>
      <p>
        We can clearly see why it's called symmetry. If we were to fold this
        over the diagonal, the ones and zeroes would perfectly match. An element
        of the diagonal, if included, is symmetric by default (because the
        element on the opposite side of the diagonal is itself, which is
        included), so the diagonal has no impact on symmetry.
      </p>
      <h3>Antisymmetry</h3>
      <p>
        This one states that if (a, b) is an element of ρ, then (b, a) must not
        be, <strong>unless</strong> they are the same element. So again, we're
        ignoring the diagonal. When folded over the diagonal, two ones can't
        overlap (it's fine if zeroes do). Formally:
      </p>
      <CustomLatex
        latex={
          "(a, b) \\in \\rho \\space \\text\{and\} \\space (b, a) \\in \\rho \\implies a = b"
        }
      />
      <h3>Transitivity</h3>
      <p>
        This one doesn't visualize well, but it is as simple as the others. It states that if (a, b) in ρ and (b, c) in ρ, then (a,
        c) is also in ρ:
      </p>
      <CustomLatex
        latex={"(a, b), (b, c) \\in \\rho \\implies (a, c) \\in \\rho"}
      />
      <p>This is best shown with an example. If 3 &lt; 5 and 5 &lt; 7, 3 has to be less than 7 if the relation is transitive. Another example is divisibility:</p>
      <CustomLatex latex="(a, b) \in \rho \implies a|b" />
      <p><CustomLatex latex="a" block={false} /> divides <CustomLatex latex="b" block={false} /> if <CustomLatex latex="a" block={false} /> can be multiplied by some number to get <CustomLatex latex="b" block={false} />. 4 can be multiplied by 3 to get 12. Let's label the number we used to multiply <CustomLatex latex="a" block={false} /> as <CustomLatex latex="x" block={false} /> <CustomLatex latex="(a \times x = b)" block={false} />. If <CustomLatex latex="b" block={false} /> divides another number <CustomLatex latex="c" block={false} />, that means there is a <CustomLatex latex="y" block={false} /> such that <CustomLatex latex="b \times y = c" block={false} />. Now we can just substitute <CustomLatex latex="b" block={false} /> for <CustomLatex latex="a \times x" block={false} /> to get <CustomLatex latex="a \times x \times y = c" block={false} />. We've just proved that if <CustomLatex latex="a" block={false} /> divides <CustomLatex latex="b" block={false} /> and <CustomLatex latex="b" block={false} /> divides <CustomLatex latex="c" block={false} />, there will always be a number <CustomLatex latex="x \times y" block={false} /> that can multiply <CustomLatex latex="a" block={false} /> to get <CustomLatex latex="c" block={false} />.</p>

      <p>Here is what this looks like: <CustomLatex latex="\small 11" block={false} /> divides <CustomLatex latex="\small 77" block={false} /> <CustomLatex latex="\small (77 = 7 \times 11)" block={false} />. <CustomLatex latex="\small 77" block={false} /> divides <CustomLatex latex="\small 231" block={false} /> <CustomLatex latex="\small (231 = 3 \times 77)" block={false} />. We can take the original <CustomLatex latex="\small 11" block={false} />, multiply by <CustomLatex latex="\small 7" block={false} /> to get <CustomLatex latex="\small 77" block={false} />, and multiply again by <CustomLatex latex="\small 3" block={false} /> to get <CustomLatex latex="\small 231" block={false} /> <CustomLatex latex="\small (231 = (7 \times 3) \times 11 = 21 \times 11)" block={false} />.</p>
      <h2>Important relations</h2>
      <h3>Equivalence relations</h3>
      <p>
        These relations are reflexive, symmetric, and transitive. This is
        basically a relation that contains pairs of elements considered equal.
        Reflexivity is obvious here because an element and that same
        element are, in fact, the same. It has to be symmetric because if a = b,
        then they are the same, so b = a must also be true. It's transitive
        because a = b = c means these are all the same, so a = c has to be true.
        When I say they are the same, I mean they are considered equal under the relation.
      </p>
      <p>
        An equivalence relation breaks up the set into classes. These classes
        are just sets where the elements are considered equal under the
        relation. So if we had a relation where two elements are related if they
        have the same remainder when divided by three, this relation would break
        up the set into 3 classes. One for elements that have a remainder of 0,
        one for the elements that have a remainder of 1, and one for elements
        that have a remainder of 2. We'd write this relation as:
      </p>
      <CustomLatex
        latex={
          "(\\forall a, b \\in \\N) \\space a \\rho b \\iff a \\equiv b \\space (\\text\{mod 3\})"
        }
      />
      <p>And the classes would look like:</p>
      <CustomLatex latex= "[0] = \{0, 3, 6, 9, \dots \}" />
      <CustomLatex latex="[1] = \{1, 4, 7, 10, \dots \}" />
      <CustomLatex latex="[2] = \{2, 5, 8, 11, \dots \}" />
      <p>
        <CustomLatex latex="\small [0]" block={false} /> This notation is used to represent a class, and it means this is a
        set of all elements related to the element 0 (in this instance that
        would be all the elements with the same remainder after dividing by 3).
        The number inside the bracket is called the representative, and it can
        be any element of the class. So [0] = [3] = [6] and so on. One important
        point is that two different classes are disjoint, so&nbsp;
        <CustomLatex latex={"\\small [0] \\bigcup [1] = \\emptyset"} block={false} />
      </p>
      <h2>Partial order relations</h2>
      <p>
        Are relations that are reflexive, transitive, and antisymmetric. We can
        think of them as relations where elements can be ordered in some way but
        also equal. One example is the classic less than or equal relation (≤).
        The equality here requires reflexivity. They are antisymmetric because
        they define some kind of order, so if a is before b (a, b), then b can't
        be before a (b, a). They are transitive because if a before b and b
        before c, a obviously has to be before c. I use the word 'before'
        because it's an easy way to remember what these relations represent
        and what properties they must have.
      </p>
      <table className="square-table" style={{"--rows": 6} as React.CSSProperties}>
      <thead>
         <tr>
          <th><div><CustomLatex latex="\small A" block={false} /></div></th>
          <th><div><CustomLatex latex="\small a" block={false} /></div></th>
          <th><div><CustomLatex latex="\small b" block={false} /></div></th>
          <th><div><CustomLatex latex="\small c" block={false} /></div></th>
          <th><div><CustomLatex latex="\small d" block={false} /></div></th>
          <th><div><CustomLatex latex="\small e" block={false} /></div></th>
        </tr>
 
      </thead>

      <tbody>
         <tr>
          <th><div><CustomLatex latex="\small a" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small b" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small c" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small d" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
        </tr>
        <tr>
          <th><div><CustomLatex latex="\small e" block={false} /></div></th>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 0" block={false} /></div></td>
          <td><div><CustomLatex latex="\small 1" block={false} /></div></td>
        </tr>
 
      </tbody>
              </table>
      <p>Our relation looks like this:</p>
      <CustomLatex latex="\rho = \{(a, a), (b, b), (b, c), \\ (c, c), (d, b), (d, c), (d, d), \\ (e, b), (e, c), (e, e)\}" />
      <p>
        As we can see, I'm not following any rule or logic to define
        this. I just picked random values and made sure reflexivity, antisymmetry,
        and transitivity are satisfied. There are elements that are not related,
        and we call them incomparable. For example, there is no order defined
        between the elements a and c. If all elements are comparable, this is called
        a total order. The ordered pair containing the set and the relation (A, ρ)
        is called a poset.
      </p>
    </div>
};

export default BinaryRelations;
