import type { Config } from "@react-router/dev/config";

export default {
  // Config options...
  // Server-side render by default, to enable SPA mode set this to `false`
  ssr: false,
  basename: "/uui-2025/studenti/ognjen_antonic_mi25204/"
} satisfies Config;
